import { makeStyles } from "@mui/styles";
export const useStyles = makeStyles({
  font: {
    fontFamily: "Roboto !important",
  },
});
